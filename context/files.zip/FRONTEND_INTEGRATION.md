# Frontend Integration - News Intelligence Engine

Two files you shared can be patched directly, in place, with no new
routes or components. A third piece depends on files you haven't
shared.

## 1. `src/pages/LegislativeTracker.tsx` - `intelligenceAlerts` fetch

This is the one place in the frontend that already reads
`bill_news_mentions` for the sovereign stream carousel. It needs two
changes: filter to fused signals only (so unverified scrapes never
reach the homepage), and pull `story_dna` so general civic news (no
bill attached) can still show a topic badge instead of a blank "Re:"
line.

**Find** (inside the `fetchIntelligence` effect):

```tsx
const { data, error } = await (supabase as any)
  .from('bill_news_mentions')
  .select(`
    id,
    headline,
    bill_id,
    source_name,
    bills (
      id,
      title
    )
  `)
  .order('scraped_at', { ascending: false })
  .limit(8);
```

**Replace with:**

```tsx
const { data, error } = await (supabase as any)
  .from('bill_news_mentions')
  .select(`
    id,
    headline,
    bill_id,
    source_name,
    story_dna,
    bills (
      id,
      title
    )
  `)
  .eq('fusion_status', 'fused')
  .order('scraped_at', { ascending: false })
  .limit(8);
```

`fusion_status = 'fused'` is what keeps this safe to add immediately:
the migration backfills every existing bill-tied row to `'fused'`, so
nothing currently showing on the site disappears. Only new,
not-yet-corroborated signals are held back until `news_fusion_relay.py`
verifies them.

**Find** (inside the intelligence alert render branch, the part that
currently only renders something when a bill is attached):

```tsx
{activeSovereignItem.data.bills?.title && (
  <div className="flex items-center justify-between pt-2">
    <div className="text-[10px] font-bold opacity-40 uppercase tracking-widest">
      Re: {activeSovereignItem.data.bills.title}
    </div>
    <Button
      variant="link"
      asChild
      className="p-0 h-auto text-kenya-green font-black text-xs uppercase tracking-widest gap-2"
    >
      <Link to={`/bill/${activeSovereignItem.data.bill_id}`}>
        See Bill Here <ArrowRight className="h-3 w-3" />
      </Link>
    </Button>
  </div>
)}
```

**Replace with** (adds a topic pill for general civic news that has no
bill attached, instead of rendering nothing):

```tsx
{activeSovereignItem.data.bills?.title ? (
  <div className="flex items-center justify-between pt-2">
    <div className="text-[10px] font-bold opacity-40 uppercase tracking-widest">
      Re: {activeSovereignItem.data.bills.title}
    </div>
    <Button
      variant="link"
      asChild
      className="p-0 h-auto text-kenya-green font-black text-xs uppercase tracking-widest gap-2"
    >
      <Link to={`/bill/${activeSovereignItem.data.bill_id}`}>
        See Bill Here <ArrowRight className="h-3 w-3" />
      </Link>
    </Button>
  </div>
) : activeSovereignItem.data.story_dna?.topics?.[0] ? (
  <div className="pt-2">
    <Badge
      variant="outline"
      className="text-[9px] font-black uppercase tracking-widest border-primary/20 text-primary"
    >
      {activeSovereignItem.data.story_dna.topics[0]}
    </Badge>
  </div>
) : null}
```

No other change needed in this file. `Badge` is already imported at
the top of the file.

Optional, for type clarity (this data is currently typed `any[]` via
`useState<any[]>([])` for `intelligenceAlerts` - not required, but
matches the precision the rest of the file uses for `Bill`):

```tsx
interface IntelligenceAlert {
  id: string;
  headline: string;
  bill_id: string | null;
  source_name: string | null;
  story_dna: { topics?: string[]; who?: string; what?: string } | null;
  bills: { id: string; title: string } | null;
}
```

and change `useState<any[]>([])` to `useState<IntelligenceAlert[]>([])`.

## 2. `src/components/.../CivicMiniPlayer.tsx` - general civic news in the rotating content

`contentItems` (the array that drives the Stage B mini-bar's rotating
title/subtitle and the Stage C "Now" slide) is built entirely inside
this file, from `latestHeadline`, `followedBills`, `upcomingEvents`,
`recentBills`, and `participatedCampaigns`. None of those currently
carry general (non-bill) civic news, so this file can source it
directly without touching `useCivicPlayerData` or `useCivicPlayerStore`.

**Add**, near the other `useState` declarations:

```tsx
const [civicIntelItems, setCivicIntelItems] = useState<
  { content_id: string; title: string; excerpt: string | null; url: string | null }[]
>([]);
```

**Add**, near the other top-level `useEffect`s (runs once, not gated
on `user` - this is public content):

```tsx
useEffect(() => {
  const fetchCivicIntel = async () => {
    const { data } = await (supabase as any)
      .from('trending_cache')
      .select('content_id, title, excerpt, url')
      .eq('content_type', 'civic_intel')
      .order('recency_score', { ascending: false })
      .limit(5);
    if (data) setCivicIntelItems(data);
  };
  fetchCivicIntel();
}, []);
```

**Find**, inside the `contentItems` `useMemo`:

```tsx
const contentItems: MiniContent[] = React.useMemo(() => {
  const items: MiniContent[] = [];
  if (latestHeadline) items.push({ title: latestHeadline, type: 'Live Update', link: '/legislative-tracker' });
  followedBills.slice(0, 3).forEach(b => items.push({ title: b.title, type: 'Bill', link: `/bill/${b.slug || b.id}` }));
```

**Replace with** (adds up to 3 civic-intel headlines right after the
live update, before followed bills):

```tsx
const contentItems: MiniContent[] = React.useMemo(() => {
  const items: MiniContent[] = [];
  if (latestHeadline) items.push({ title: latestHeadline, type: 'Live Update', link: '/legislative-tracker' });
  civicIntelItems.slice(0, 3).forEach(n =>
    items.push({ title: n.title, type: 'News', link: n.url || '/legislative-tracker', summary: n.excerpt || undefined })
  );
  followedBills.slice(0, 3).forEach(b => items.push({ title: b.title, type: 'Bill', link: `/bill/${b.slug || b.id}` }));
```

**Find** the closing dependency array of that same `useMemo`:

```tsx
  }, [latestHeadline, followedBills, upcomingEvents, recentBills, participatedCampaigns]);
```

**Replace with:**

```tsx
  }, [latestHeadline, civicIntelItems, followedBills, upcomingEvents, recentBills, participatedCampaigns]);
```

That's the full change. `MiniContent` already has an optional
`summary` field, and the `Ticker` and rotating-title rendering both
already work off `content.type` / `content.title` generically, so a
`type: 'News'` item renders correctly with no further edits.

## 3. What I can't patch directly

`useCivicPlayerData` and `useCivicPlayerStore` weren't shared, so I
can't see what currently computes `temperature` (`'cool' | 'warm' | 'hot'`,
which drives the FAB's pulsing icon and color) or `latestHeadline`
itself. If you want the FAB's temperature to also react to NIO
velocity (for example, `hot` when a `developing` NIO has
`velocity >= 60`), that logic lives in whichever of those two files
computes `temperature` today - point me at that file's contents and
I'll write the exact patch the same way as the two above, rather than
guessing at its current shape.
